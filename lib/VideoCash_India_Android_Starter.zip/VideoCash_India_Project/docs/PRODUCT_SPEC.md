# VideoCash UAE — MVP product specification

## Product
Android-first UGC video platform for short and long videos.

## Roles
- Viewer: watch, like, comment, report, block.
- Creator: all viewer features plus upload, creator dashboard and payout onboarding.
- Moderator: review reports and uploads, remove content, suspend accounts.
- Admin/finance: configure monetization rules, reconcile revenue, review payout batches.

## MVP screens
1. Welcome, sign-up/sign-in, age gate, terms acceptance.
2. Home feed with short/long filters.
3. Video player, creator profile, likes/comments/share/report/block.
4. Upload with title, caption, category, visibility and progress.
5. Creator studio: qualified views, estimated earnings, finalized earnings.
6. Wallet: ledger, payout method onboarding, withdrawal request and status.
7. Settings: privacy, account deletion, community rules and support.
8. Admin web dashboard (separate web app).

## Earnings model (safe implementation)
- Qualified views: count only server-validated views; exclude bots, repeated loops, self-views and suspicious traffic.
- Ad/sponsor revenue share: distribute only finalized net revenue from direct advertiser campaigns or other approved revenue sources.
- Never treat a Google AdMob rewarded-ad view/click as cash-earning eligibility. AdMob policy does not allow cash or other direct monetary rewards for rewarded ads and prohibits Google ads in apps promising payment for ad views/clicks.
- Display estimated and finalized balances separately.
- Keep an immutable, auditable wallet ledger. Never trust client-calculated balances.

## Required backend collections (illustrative)
- users, creator_profiles, videos, video_metrics, comments, likes, reports, blocks
- campaigns, campaign_deliveries, revenue_settlements
- wallet_accounts, wallet_ledger, payout_methods, payout_requests
- moderation_actions, audit_logs

## Launch blockers
- UAE business/media activity review and required approvals.
- Privacy policy, terms, copyright process, moderation operations and age screening.
- Payment provider approval, KYC/AML, payout reconciliation and dispute handling.
- Data protection, secure video storage, content scanning and abuse prevention.
