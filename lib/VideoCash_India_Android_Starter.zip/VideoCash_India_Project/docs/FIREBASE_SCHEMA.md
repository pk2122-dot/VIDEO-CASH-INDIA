# Backend schema outline (not deployed)

Use Firebase Authentication for identity and a trusted backend (Cloud Functions or a dedicated API) for privileged operations.

## Firestore
- `users/{uid}`: displayName, email/phone (provider-managed), dateOfBirth/ageGateStatus, role, createdAt, status
- `creators/{uid}`: handle, bio, verificationStatus, payoutProviderCustomerId
- `videos/{videoId}`: creatorUid, title, caption, storagePath, playbackUrl, durationSeconds, visibility, moderationStatus, createdAt
- `videoStats/{videoId}`: qualifiedViews, likes, comments (server-maintained)
- `reports/{reportId}`: reporterUid, targetType, targetId, reason, status, createdAt
- `walletLedger/{entryId}`: uid, type, amountMinor, currency, sourceId, status, createdAt (backend write only)
- `payoutRequests/{requestId}`: uid, amountMinor, provider, status, createdAt (backend write only)

## Security principles
- Clients may create upload requests and reports, but cannot write wallet balances, qualified view counts, finalized revenue or payout status.
- Validate file MIME type, duration, size and ownership server-side.
- Use signed upload/playback URLs where appropriate.
- Add App Check, rate limits, abuse detection, audit logs and least-privilege admin roles.
- Store money as integer minor units (fils), not floating-point values.
- Payouts require KYC and provider-side confirmation; never mark paid based only on a client response.
