# VideoCash India — Android Starter

Yeh Flutter Android starter project hai. Ismein Home feed, Upload, Wallet aur Profile ke working UI tabs hain. Yeh abhi **demo frontend** hai; real user accounts, video upload/playback, creator earnings, withdrawals aur admin panel connected nahi hain.

## Android app chalane ke liye

1. Computer par Flutter SDK aur Android Studio install karein.
2. Is folder ko extract karein.
3. Terminal mein project folder kholkar chalayein:
   - `flutter pub get`
   - `flutter run`
4. APK banane ke liye: `flutter build apk --release`

## Agla development phase

- Firebase Authentication: email/phone sign-in, age gate, account deletion.
- Firebase Storage / video hosting: resumable uploads, transcoding, thumbnails, CDN.
- Firestore / backend: videos, likes, comments, reports, creator profiles.
- Admin web dashboard: review queue, takedown, user suspension, payout review.
- Server-side earnings ledger: qualified views, fraud checks, finalized advertiser revenue, creator share.
- Payout integration: UAE-supported licensed payment provider, KYC/AML checks, bank and wallet rails.

## Important monetization and policy notes

- Google AdMob publisher revenue is paid to the app publisher, not automatically to individual creators.
- Do not promise cash for users watching/clicking Google ads. AdMob policy prohibits Google ads in apps that promise payment/incentives for viewing or clicking ads. Rewarded-ad rewards must be eligible non-cash in-app items.
- Creator revenue sharing should be based on independently funded advertiser/sponsorship campaigns or another approved monetization arrangement, with finalized revenue and fraud checks.
- Before UAE commercial launch, confirm the exact business activity, licensing and media requirements with the relevant UAE authorities and a qualified local advisor. TDRA lists an e-activity NOC process; UAE media authorities list media/advertising permits and relevant activity categories.
- Publish only after implementing UGC terms acceptance, reporting, blocking, content moderation, age screening, privacy policy and account deletion.

## Security rules

Never calculate or credit cash earnings from client-side app code. All wallet entries and payout approvals must be created by trusted backend services. Do not store card details or identity documents directly in the app database unless the approved provider and security design require it.


## Phone-only APK build (GitHub Actions)

1. Extract this ZIP on your Android phone.
2. Create a GitHub repository. For a zero-cost public build workflow, choose Public (the source will be visible to everyone); do not upload passwords, API keys, private user data or signing keys.
3. Upload the extracted project files and folders to the repository root (including the hidden `.github` folder; if the mobile uploader hides it, create `.github/workflows/build-android-apk.yml` manually and paste the workflow file from this ZIP).
4. Open the repository's Actions tab and run `Build VideoCash India APK` (or push a commit to `main`).
5. When the run finishes, open the workflow run, scroll to Artifacts, and download `videocash-uae-release-apk`. Extract the downloaded artifact ZIP to get `app-release.apk`.
6. Install only on your own test phone first. Android may ask you to allow installs from that browser/file manager.

Public repositories' standard GitHub-hosted Actions runners are free. Private repositories use plan quotas. See GitHub's official Actions billing documentation.
