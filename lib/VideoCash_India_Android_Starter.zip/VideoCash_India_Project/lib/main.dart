import 'package:flutter/material.dart';

void main() => runApp(const VideoCashApp());

const brandGreen = Color(0xFF16A36A);
const ink = Color(0xFF101B17);

class VideoCashApp extends StatelessWidget {
  const VideoCashApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VideoCash UAE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brandGreen),
        scaffoldBackgroundColor: const Color(0xFFF6F8F7),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: ink,
          foregroundColor: Colors.white,
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  final pages = const [
    FeedPage(),
    UploadPage(),
    WalletPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('VideoCash UAE', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            onPressed: () => _message('Notifications will be enabled after backend setup.'),
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.cloud_upload_outlined), label: 'Upload'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }
}

class FeedPage extends StatelessWidget {
  const FeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Discover videos', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Short clips and long-form videos from UAE creators.'),
        const SizedBox(height: 16),
        _VideoCard(
          title: 'Welcome to VideoCash UAE',
          creator: '@videocash',
          duration: '00:30',
          description: 'Your creator community starts here.',
        ),
        _VideoCard(
          title: 'Creator tips and ideas',
          creator: '@community',
          duration: '08:15',
          description: 'A sample long-video card for the first prototype.',
        ),
        const SizedBox(height: 12),
        const _InfoBanner(
          text: 'Demo feed: real uploads, playback, likes, comments and moderation will connect to the backend in the next development phase.',
        ),
      ],
    );
  }
}

class _VideoCard extends StatelessWidget {
  final String title;
  final String creator;
  final String duration;
  final String description;

  const _VideoCard({
    required this.title,
    required this.creator,
    required this.duration,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 190,
            width: double.infinity,
            color: ink,
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(Icons.play_circle_fill, color: Colors.white, size: 64),
                Positioned(
                  right: 12,
                  bottom: 12,
                  child: DecoratedBox(
                    decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(6)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: Text(duration, style: const TextStyle(color: Colors.white)),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              const SizedBox(height: 4),
              Text('$creator  ·  $description', style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 10),
              Row(children: [
                const Icon(Icons.favorite_border, size: 19),
                const SizedBox(width: 5),
                const Text('Like'),
                const SizedBox(width: 22),
                const Icon(Icons.chat_bubble_outline, size: 19),
                const SizedBox(width: 5),
                const Text('Comment'),
                const Spacer(),
                TextButton(onPressed: () => _showDemo(context), child: const Text('Watch')),
              ]),
            ]),
          ),
        ],
      ),
    );
  }

  void _showDemo(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Video playback is a backend integration task.')),
    );
  }
}

class UploadPage extends StatefulWidget {
  const UploadPage({super.key});

  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  String type = 'Short video';

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Upload a video', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Creators will be able to publish short and long videos after sign-in and storage are connected.'),
      const SizedBox(height: 20),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'Short video', label: Text('Short')),
          ButtonSegment(value: 'Long video', label: Text('Long')),
        ],
        selected: {type},
        onSelectionChanged: (value) => setState(() => type = value.first),
      ),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          border: Border.all(color: brandGreen, style: BorderStyle.solid),
          borderRadius: BorderRadius.circular(18),
          color: Colors.white,
        ),
        child: const Column(children: [
          Icon(Icons.video_library_outlined, size: 58, color: brandGreen),
          SizedBox(height: 12),
          Text('Choose video', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          SizedBox(height: 6),
          Text('MP4 / MOV · File size and duration limits will be enforced by the server.'),
        ]),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: () => _notice('Upload picker is not connected yet. Next step: Firebase Storage + video picker.'),
        icon: const Icon(Icons.add),
        label: Text('Select $type'),
      ),
      const SizedBox(height: 12),
      const _InfoBanner(text: 'Every upload must pass community rules and moderation checks before it is recommended publicly.'),
    ]);
  }

  void _notice(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Creator wallet', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      Card(
        color: ink,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Estimated balance', style: TextStyle(color: Colors.white70)),
            SizedBox(height: 8),
            Text('AED 0.00', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Demo balance · no real money is being credited', style: TextStyle(color: Colors.white70)),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      const Text('Earning sources', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      const ListTile(leading: Icon(Icons.visibility_outlined), title: Text('Qualified video views'), subtitle: Text('Subject to eligibility and anti-fraud checks')),
      const ListTile(leading: Icon(Icons.campaign_outlined), title: Text('Advertiser revenue share'), subtitle: Text('Only from approved, paid campaigns and finalized revenue')),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () => _notice(context, 'Withdrawals will open after identity, payment-provider and legal verification.'),
        icon: const Icon(Icons.account_balance),
        label: const Text('Add bank / wallet payout method'),
      ),
      const SizedBox(height: 8),
      const _InfoBanner(text: 'No guaranteed earnings. Payout thresholds, fees, KYC and supported UAE payment providers must be configured before launch.'),
    ]);
  }

  void _notice(BuildContext context, String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 42)),
      const SizedBox(height: 12),
      const Center(child: Text('Creator profile', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      const Center(child: Text('Sign-in and creator verification required')),
      const SizedBox(height: 22),
      const ListTile(leading: Icon(Icons.video_collection_outlined), title: Text('My videos'), trailing: Text('0')),
      const ListTile(leading: Icon(Icons.people_outline), title: Text('Followers'), trailing: Text('0')),
      const ListTile(leading: Icon(Icons.flag_outlined), title: Text('Community guidelines')),
      const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy and terms')),
      const ListTile(leading: Icon(Icons.support_agent), title: Text('Help and report a problem')),
    ]);
  }
}

class _InfoBanner extends StatelessWidget {
  final String text;
  const _InfoBanner({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFFE7F4ED), borderRadius: BorderRadius.circular(12)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.info_outline, color: brandGreen),
        const SizedBox(width: 10),
        Expanded(child: Text(text)),
      ]),
    );
  }
}
